package com.example.diet_gamification.model

data class FoodItem(
    val category: String,
    val name: String,
    val calories: Int
)
