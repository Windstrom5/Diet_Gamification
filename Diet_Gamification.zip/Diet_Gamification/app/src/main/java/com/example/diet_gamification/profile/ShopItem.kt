package com.example.diet_gamification.profile

data class ShopItem(
    val id: Int,
    val name: String,
    val price: Int,
    val description: String
)
