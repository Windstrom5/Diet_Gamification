package com.example.diet_gamification.todolist

data class FoodEntry(
    val name: String,
    val calories: Int
)
